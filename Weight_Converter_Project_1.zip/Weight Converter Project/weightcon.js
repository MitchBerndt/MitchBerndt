let button = document.getElementById('btn');

button.addEventListener('click',function(){
        let gram = parseInt(document.getElementById('grams').value);
        let type = document.getElementById('type').value;

        if(gram === '' || isNaN(gram)){
            document.getElementById('grams').focus();
            document.getElementById('error').innerHTML = 'Please provide a valid gram ';
            document.getElementById('output').innerHTML = '';
        }else{
            document.getElementById('error').innerHTML = '';
            switch(type){
                case 'Pounds':
                    convert_pounds(gram);
                    break;
                case 'Kilograms':
                    convert_kilogram(gram);
                    break;
                case 'Ounces':
                    convert_ounces(gram);
                    break;   
                case 'USTon':
                    convert_uston(gram);
                    break;  
                default:
                    alert('error');       
            }
            function convert_pounds(gram){
                let rate = 0.0022, pounds;
                pounds = gram * rate;
                document.getElementById('output').innerHTML = gram + " Grams = " +
                pounds.toFixed(3) + ' Pounds.';
            }
            function convert_kilogram(gram){
                let rate = 0.001, kilogram;
                kilogram = gram * rate;
                document.getElementById('output').innerHTML = gram + " Grams = " +
                kilogram.toFixed(3) + ' Kilograms.';
            }
            function convert_ounces(gram){
                let rate = 0.035274, ounces;
                ounces = gram * rate;
                document.getElementById('output').innerHTML = gram + " Grams = " +
                ounces.toFixed(3) + ' Ounces.';
            }
            function convert_uston(gram){
                let rate = 0.0000011023, uston;
                uston = gram * rate;
                document.getElementById('output').innerHTML = gram + " Grams = " +
                uston.toFixed(3) + ' US Ton.';
            }
        }
});
button.addEventListener('click',function(){
    let pound = parseInt(document.getElementById('pounds').value);
    let type1 = document.getElementById('type1').value;
        if(pound === '' || isNaN(pound)){
            document.getElementById('pounds').focus();
            document.getElementById('error1').innerHTML = 'Please provide a valid pound ';
            document.getElementById('output1').innerHTML = '';
        }else{
            document.getElementById('error1').innerHTML = '';
            switch(type1){
                case 'Grams':
                    convert_grams(pound);
                    break;
                case 'Kilograms':
                    convert_kilogram(pound);
                    break;
                case 'Ounces':
                    convert_ounces(pound);
                    break;   
                case 'USTon':
                    convert_uston(pound);
                    break;  
                default:
                    alert('error1');      
            }
            function convert_grams(pound){
                let rate = .454, grams;
                grams = pound * rate;
                document.getElementById('output1').innerHTML = pound + " Pounds = " +
                grams.toFixed(3) + ' Grams.';
            }
            function convert_kilogram(pound){
                let rate = 0.001, kilogram;
                kilogram = pound * rate;
                document.getElementById('output1').innerHTML = pound + " Pounds = " +
                kilogram.toFixed(3) + ' Kilograms.';
            }
            function convert_ounces(pound){
                let rate = 0.035274, ounces;
                ounces = pound * rate;
                document.getElementById('output1').innerHTML = pound + " Pounds = " +
                ounces.toFixed(3) + ' Ounces.';
            }
            function convert_uston(pound){
                let rate = 0.0000011023, uston;
                uston = pound * rate;
                document.getElementById('output1').innerHTML = pound + " Pounds = " +
                uston.toFixed(3) + ' US Ton.';
            }
        }
});
    let slidesContainer = document.getElementById("slide-contain");
    let slide = document.querySelector(".slide");
    let prevButton = document.getElementById("slide-arrow-prev");
    let nextButton = document.getElementById("slide-arrow-next");

        nextButton.addEventListener("click", () => {
        let slideWidth = slide.clientWidth;
        slidesContainer.scrollLeft += slideWidth;
        });

        prevButton.addEventListener("click", () => {
        let slideWidth = slide.clientWidth;
        slidesContainer.scrollLeft -= slideWidth;
        });
    let input = document.getElementById('grams','pounds');
             input.addEventListener("keypress",function(entbtn) {
                if (entbtn.key === 'Enter') {
                 entbtn.preventDefault();
                 document.getElementById('btn').click()
              }
          });